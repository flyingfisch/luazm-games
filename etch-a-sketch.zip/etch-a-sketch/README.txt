ETCH-A-SKETCH v1.2
by TakeFlight Productions (flyingfisch)

Licensed with the CC Share and shre alike license: 
http://creativecommons.org/licenses/by-sa/3.0/

Controls:
[F1]/[F2] :: Up/Down
[F5]/[F6] :: Right/Left
[ALPHA] :: Clear
[OPTN] :: This help message

Have fun!

